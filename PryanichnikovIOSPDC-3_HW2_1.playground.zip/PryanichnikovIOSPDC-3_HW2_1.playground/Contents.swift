import UIKit
//Задача 1
/*
 1. Пряничников Семён
 2. Люблю узнавать новое в сфере IT и копаться в различного рода технике, много работаю, мало отдыхаю.
 3. Есть очень небольшой опыт разработки на С++ и С#
 4. Снифферы Charles, fiddler. Система мониторинга Zabbix. Среда разработки Microsoft Visual Studio
 5. 5 лет - Системный администратор
 6. Техник-программист
 */

//Задача 2
let myFirstName: String = "Simon"
let mySecondName: String = "Pryanichnikov"
var myAge: Int = 25
let myGender: String = "Male"
var cityForRelacation: String = "Krakow"
let experienceOfUsingMacOs: Bool = true
var desiredSalary: Int = 160000
var numberOfDaysVacation: Int = 14
let myFavoriteColor: String = "Red"

//Задача 3
var salaryMiddleIosDev: Double = 150000
var salaryJuniorIosDev = 80000
var salaryMiddleAndroidDev = 140000

salaryMiddleIosDev *= 1.2
salaryJuniorIosDev += 20000
salaryMiddleAndroidDev *= 1

print(salaryMiddleIosDev, "\n", salaryJuniorIosDev, "\n", salaryMiddleAndroidDev)
